
// function login(){

//     var person = {"name":"z长",age:23,'gender':true};
//     alert(person);

//     if(document.getElementById('login_name').value==1){
//         alert(44444);
//     }  
// }

function login(){
   var name=document.getElementById("name");
   var pass=document.getElementById("passw");
                
    req = {"username":name,"password":pass}
    $.ajax({
     type: 'POST',
     url: "/login",
     data: JSON.stringify(req),
     dataType:"json",
     success: function (data) {
     if(data['role_id']==2) {
     window.location.href="./producer";
     }else if(data['status']==1 && data['identity']==2){
     window.location.href="./seller";
     }else{
     alert("Wrong account name or password, please try again.")
      }
    }
  });
}



function register() {
    window.open("./UserRegister.html");
    alert("1111");
}
   